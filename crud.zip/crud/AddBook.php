<!-- <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Online Library | Bookstore</title>
  </head>

  <body>
    <nav>
      <div class="menu-icon"></div>
      <div class="logo">Digital Library</div>
    </nav>
    
    <div id="buyer-box">
      <h1 class="heading">Online Library and Bookstore</h1>
      
      <div class="input-data">
        <a href="adminManageBooks.html">
          <img class="arrow" src="../src/images/arrow.png" >
        </a>
        <h2>Edit Book Record</h2>
        
        <link rel="stylesheet" href="addBook.css" />

        <input id="book_id1" type="text" placeholder="Book ID" name="bookID"/>
        <input id="book_title1" type="text" placeholder="Book Title" name="bookTitle"/>
        <input id="author_name1" type="text" placeholder="Author name" name="author"/>
        <input id="book_price1" type="text" placeholder="Book Price" name="bookPrice"/>

        <input id="insert" type="submit" name="Add_book" value="Add" />
        <input id="select" type="submit" name="select" value="Load" />
        <input id="update" type="submit" name="update_book" value="Update" />
        <input id="delete" type="submit" name="delete_book" value="Remove" />
      </div>

      <div class="right"></div>
    </div>

    <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-database.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script id="mainScript">
      var firebaseConfig = {
        apiKey: "AIzaSyDHJ_-ZQYPFVq7-NtsJXXMFKnga9dxGpVM",
        authDomain: "library-20343.firebaseapp.com",
        databaseURL: "https://library-20343-default-rtdb.firebaseio.com",
        projectId: "library-20343",
        storageBucket: "library-20343.appspot.com",
        messagingSenderId: "212815264632",
        appId: "1:212815264632:web:a934e86c5eb179e911e68d",
        measurementId: "G-9EELX46W32",
      };
      firebase.initializeApp(firebaseConfig);

      var bookID, bookTITLE, authorNAME, bookPRICE;

      function ready() {
        bookID = document.getElementById("book_id1").value;
        bookTITLE = document.getElementById("book_title1").value;
        authorNAME = document.getElementById("author_name1").value;
        bookPRICE = document.getElementById("book_price1").value;
      }

      function clear() {
        document.getElementById("book_id1").value = null;
        document.getElementById("book_title1").value = null;
        document.getElementById("author_name1").value = null;
        document.getElementById("book_price1").value = null;
      }

      document.getElementById("insert").onclick = function () {
        ready();
        if (document.getElementById("book_id1").value == "") {
          alert("Please enter Book ID.");
        } else {
          firebase
            .database()
            .ref("AddBook/" + bookID)
            .set({
              bookId: bookID,
              bookTitle: bookTITLE,
              AuthorName: authorNAME,
              BookPrice: bookPRICE,
            });
          swal({
            title: "Added!",
            text: "Book added in Library/Boookstore!",
            icon: "success",
          });
          clear();
        }
      };

      document.getElementById("select").onclick = function () {
        ready();
        firebase
          .database()
          .ref("AddBook/" + bookID)
          .on("value", function (snapshot) {
            document.getElementById("book_id1").value = snapshot.val().bookId;
            document.getElementById(
              "book_title1"
            ).value = snapshot.val().bookTitle;
            document.getElementById(
              "author_name1"
            ).value = snapshot.val().AuthorName;
            document.getElementById(
              "book_price1"
            ).value = snapshot.val().BookPrice;
          });
      };

      document.getElementById("delete").onclick = function () {
        ready();
        firebase
          .database()
          .ref("AddBook/" + bookID)
          .remove();
        swal({
          title: "Removed!",
          text: "Book removed from Library/Boookstore!",
          icon: "success",
        });
        clear();
      };

      document.getElementById("update").onclick = function () {
        ready();
        firebase
          .database()
          .ref("AddBook/" + bookID)
          .update({
            bookId: bookID,
            bookTitle: bookTITLE,
            AuthorName: authorNAME,
            BookPrice: bookPRICE,
          });
        clear();
      };
      function checkForBlanks() {
        if (document.getElementById("book_id1").value == "") {
          alert("Please enter Book ID.");
        }
        return false;
      }
    </script>
  </body>
</html> -->


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Online Library | Bookstore</title>
</head>
<body>
  <nav>
    <div class="menu-icon"></div>
    <div class="logo">Digital Library</div>
  </nav>
  
  <div id="buyer-box">
    <h1 class="heading">Online Library and Bookstore</h1>
    
    <div class="input-data">
      <a href="adminManageBooks.html">
        <img class="arrow" src="../src/images/arrow.png" >
      </a>
      <h2>Edit Book Record</h2>
      
      <link rel="stylesheet" href="addBook.css" />

      <form action="addbookintodb.php" method="post">
        <input id="book_id1" name="book_id" type="text" placeholder="book_id" />
        <input id="author_name1" name="book_author" type="text" placeholder="book_author" />
        <input id="book_title1" name="book_title" type="text" placeholder="book_title" />
        <input id="s_no1" name="s_no" type="text" placeholder="s_no" />
        
        <input id="description1" name="description" type="text" placeholder="description" />
        <input id="book_price1" name="book_price" type="text" placeholder="book_price" />
        <input id="admin_id1" name="admin_id" type="text" placeholder="admin_id" />
        <input id="library_id1" name="library_id" type="text" placeholder="library_id" />


        <button type="submit" name="btnAdd" value="insert">Add</button>
        <button type="submit" name="action" value="select">Load</button>
        



 
        <table class="table table-striped table-bordered">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
                    <?php require("read.php"); ?>
                </table>
        




      </form>
    </div>

    <div class="right"></div>
  </div>
</body>
</html>





















