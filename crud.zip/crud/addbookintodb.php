<?php
require("dbconnect.php");
if(isset($_POST["btnAdd"])){
    $book_id = htmlspecialchars(trim(stripslashes($_POST["book_id"])));
    $book_author = htmlspecialchars(trim(stripslashes($_POST["book_author"])));
    $book_title = htmlspecialchars(trim(stripslashes($_POST["book_title"])));
    $s_no = htmlspecialchars(trim(stripslashes($_POST["s_no"])));
    $description = htmlspecialchars(trim(stripslashes($_POST["description"])));
    $book_price = htmlspecialchars(trim(stripslashes($_POST["book_price"])));
    $admin_id = htmlspecialchars(trim(stripslashes($_POST["admin_id"])));
    $library_id = htmlspecialchars(trim(stripslashes($_POST["library_id"])));



    if($book_id != null && $book_author != null && $book_title != null && $s_no != null && $description != null && $book_price != null && $admin_id != null && $library_id != null){
        $query = mysqli_query($databaseconnection,"insert into new_book (book_id,book_author,book_title,s_no,description,book_price,admin_id,library_id) values
        ('$book_id','$book_author','$book_title','$s_no','$description','$book_price','$admin_id','$library_id')");
        if($query){
            echo "data inserted successfully";
        }
    }
}
?>