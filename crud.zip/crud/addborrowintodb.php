<?php
require("dbconnect.php");
if(isset($_POST["btnBorrow"])){
    $issue_date = htmlspecialchars(trim(stripslashes($_POST["issue_date"])));
    $fine = htmlspecialchars(trim(stripslashes($_POST["fine"])));
    $return_date = htmlspecialchars(trim(stripslashes($_POST["return_date"])));
    $due_date = htmlspecialchars(trim(stripslashes($_POST["due_date"])));
    $borrow_amount = htmlspecialchars(trim(stripslashes($_POST["borrow_amount"])));
    $borrow_id = htmlspecialchars(trim(stripslashes($_POST["borrow_id"])));
    $user_id = htmlspecialchars(trim(stripslashes($_POST["user_id"])));
    $book_id = htmlspecialchars(trim(stripslashes($_POST["book_id"])));
    $library_id = htmlspecialchars(trim(stripslashes($_POST["library_id"])));




    if($issue_date != null && $fine != null && $return_date != null && $due_date != null && $borrow_amount != null && $borrow_id != null && $user_id != null && $book_id != null && $library_id != null){
        $query = mysqli_query($databaseconnection,"insert into borrow_book (issue_date,fine,return_date,due_date,borrow_amount,borrow_id,user_id,book_id,library_id) values
        ('$issue_date','$fine','$return_date','$due_date','$borrow_amount','$borrow_id','$user_id','$book_id','$library_id')");
        if($query){
            echo "data inserted successfully";
        }
    }
}
?>