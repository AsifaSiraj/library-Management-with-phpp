<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Online Library | Bookstore</title>
  <link rel="stylesheet" href="../Frontend/borrowBookFillingPage.css" />
</head>

<body>
  <nav>
    <div class="menu-icon"></div>
    <div class="logo">Digital Library</div>
  </nav>
  <div id="buyer-box">
    <a href="table2.html">
      <img class="arrow" src="../src/images/arrow.png" style="width: 20px; margin-left: 4%; margin-top: 3%;">
    </a>
    <h1 class="heading">Online Library and Bookstore</h1>
    <div class="input-data">
      <h1 style="margin-top: 55px;">Borrow Book</h1>
      <form action="addborrowintodb.php" method="post">
      <input type="text" name="issue_date" placeholder="issue_date">
      <input type="text" name="fine" placeholder="fine">
      <input type="text" name="return_date" placeholder="return_date">
      <input type="text" name="due_date" placeholder="due_date">
      <input type="text" name="borrow_amount" placeholder="borrow_amount">
      <input type="text" name="borrow_id" placeholder="borrow_id">
      <input type="text" name="user_id" placeholder="user_id">
      <input type="text" name="book_id" placeholder="book_id">
      <input type="text" name="library_id" placeholder="library_id">
      <input type="submit" value="Add Borrow" name="btnBorrow">


      <table class="table table-striped table-bordered">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
                    <?php require("readborrow.php"); ?>
                </table>





      </form>
    </div>
    <div class="right"></div>
  </div>

  <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-auth.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.2.9/firebase-database.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <script>
    var firebaseConfig = {
      apiKey: "AIzaSyDHJ_-ZQYPFVq7-NtsJXXMFKnga9dxGpVM",
      authDomain: "library-20343.firebaseapp.com",
      databaseURL: "https://library-20343-default-rtdb.firebaseio.com",
      projectId: "library-20343",
      storageBucket: "library-20343.appspot.com",
      messagingSenderId: "212815264632",
      appId: "1:212815264632:web:a934e86c5eb179e911e68d",
      measurementId: "G-9EELX46W32"
    };
    firebase.initializeApp(firebaseConfig);

    var bookID, bookTITLE, authorNAME, issueDate, dueDate, returnDate, fineAmount;

    function ready() {
      bookID = document.getElementById('book_id1').value;
      bookTITLE = document.getElementById('book_title1').value;
      authorNAME = document.getElementById('author_name1').value;
      issueDate = document.getElementById('issue_date').value;
      dueDate = document.getElementById('due_date').value;
      returnDate = document.getElementById('return_date').value;
      fineAmount = document.getElementById('fine_amount').value;
    }

    function clearFields() {
      document.getElementById('book_id1').value = "";
      document.getElementById('book_title1').value = "";
      document.getElementById('author_name1').value = "";
      document.getElementById('issue_date').value = "";
      document.getElementById('due_date').value = "";
      document.getElementById('return_date').value = "";
      document.getElementById('fine_amount').value = "";
    }

    document.getElementById('insert').onclick = function () {
      ready();
      if (bookID === "") {
        alert('Please enter Book ID.');
      } else {
        userEMAIL = prompt("Confirm your email. (exclude '.com')", "e.g. xyz@gmail");
        for (var i = 0; i < userEMAIL.length; i++) {
          if (userEMAIL.charAt(i) === '.' && userEMAIL.charAt(i + 1) === 'c' && userEMAIL.charAt(i + 2) === 'o' && userEMAIL.charAt(i + 3) === 'm') {
            userEMAIL = prompt("Confirm your email. (exclude '.com')", "e.g. xyz@gmail");
          }
        }
        firebase.database().ref('BorrowedBooks/' + userEMAIL + ' ' + bookID).set({
          bookId: bookID,
          bookTitle: bookTITLE,
          AuthorName: authorNAME,
          userEmail: userEMAIL,
          issueDate: issueDate,
          dueDate: dueDate,
          returnDate: returnDate,
          fineAmount: fineAmount
        });
        swal({
          title: "Borrowed!",
          text: "You borrowed the book.",
          icon: "success"
        });
        clearFields();
      }
    }

    document.getElementById('select').onclick = function () {
      ready();
      if (bookID === "") {
        alert('Please enter Book ID.');
      } else {
        firebase.database().ref('AddBook/' + bookID).on('value', function (snapshot) {
          document.getElementById('book_id1').value = snapshot.val().bookId;
          document.getElementById('book_title1').value = snapshot.val().bookTitle;
          document.getElementById('author_name1').value = snapshot.val().AuthorName;
        })
      }
    }
  </script>

</body>
</html>
