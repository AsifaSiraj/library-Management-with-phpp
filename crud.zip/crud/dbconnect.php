<?php
$hostname = "localhost";
$username = "root";
$password = null;
$databasename = "dbmsproject";
$databaseconnection = mysqli_connect($hostname,$username,$password,$databasename);
if($databaseconnection){
    echo "database connected<br>";
}
?>