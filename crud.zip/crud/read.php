<?php
require("dbconnect.php");
?>
<?php
$query = mysqli_query($databaseconnection, "select * from new_book");
$count=1;
while($fetch = mysqli_fetch_assoc($query)){
?>
    <tr>
        <th><?php echo $count; ?></th>
        <td><?php echo $fetch["book_id"]; ?></td>
        <td><?php echo $fetch["book_title"]; ?></td>
        <td class="text-center p-3">
            <span class="bg-danger p-2 rounded-1 text-white"><a href="delete.php?deleteid=<?php echo $fetch["book_id"]; ?>" class="text-white">Delete</a></span>
            <span class="bg-primary p-2 rounded-1 text-white"><a href="updaterecord.php?updateid=<?php echo $fetch["book_id"]; ?>" class="text-white">Update</a></span>
        </td>
    </tr>
    <?php
    $count++;
}
?>