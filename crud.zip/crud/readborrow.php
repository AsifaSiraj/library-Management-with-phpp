<?php
require("dbconnect.php");
?>
<?php
$query = mysqli_query($databaseconnection, "select * from borrow_book");
$count=1;
while($fetch = mysqli_fetch_assoc($query)){
?>
    <tr>
        <th><?php echo $count; ?></th>
        <td><?php echo $fetch["borrow_id"]; ?></td>
        <td><?php echo $fetch["user_id"]; ?></td>
        <td><?php echo $fetch["book_id"]; ?></td>
        <td class="text-center p-3">
            <span class="bg-primary p-2 rounded-1 text-white"><a href="updateborrow.php?updateid=<?php echo $fetch["borrow_id"]; ?>" class="text-white">Update</a></span>
        </td>
    </tr>
    <?php
    $count++;
}
?>