<?php
require("dbconnect.php");
$issue_date = null;
$fine = null;
$return_date = null;
$due_date = null;
$borrow_amount = null;
$borrow_id = null;
$user_id = null;
$book_id = null;
$library_id = null;
if($_GET["updateid"]){
    $id = $_GET["updateid"];
    $query = mysqli_query($databaseconnection, "select * from borrow_book where borrow_id=$id");
    if($query){
        while($fetchconversion = mysqli_fetch_assoc($query)){
            $issue_date = $fetchconversion["issue_date"];
            $fine = $fetchconversion["fine"];
            $return_date = $fetchconversion["return_date"];
            $due_date = $fetchconversion["due_date"];

            $borrow_amount = $fetchconversion["borrow_amount"];

            $borrow_id = $fetchconversion["borrow_id"];

            $user_id = $fetchconversion["user_id"];
            $book_id = $fetchconversion["book_id"];

            $library_id = $fetchconversion["library_id"];

        }
    }
}
if(isset($_POST["btnUpdateBorrow"])){
    $id = $_GET["updateid"];
    $issue_date = htmlspecialchars(trim(stripslashes($_POST["issue_date"])));
    $fine = htmlspecialchars(trim(stripslashes($_POST["fine"])));
    $return_date = htmlspecialchars(trim(stripslashes($_POST["return_date"])));
    $due_date = htmlspecialchars(trim(stripslashes($_POST["due_date"])));
    $borrow_amount = htmlspecialchars(trim(stripslashes($_POST["borrow_amount"])));
    $borrow_id = htmlspecialchars(trim(stripslashes($_POST["borrow_id"])));
    $user_id = htmlspecialchars(trim(stripslashes($_POST["user_id"])));
    $book_id = htmlspecialchars(trim(stripslashes($_POST["book_id"])));
    $library_id = htmlspecialchars(trim(stripslashes($_POST["library_id"])));



    if($issue_date != null && $fine != null && $return_date != null && $due_date != null && $borrow_amount != null && $borrow_id != null && $user_id != null && $book_id != null && $library_id != null){
        $query = mysqli_query($databaseconnection,"update borrow_book set issue_date='$issue_date', fine='$fine', return_date='$return_date',
        due_date='$due_date',borrow_amount='$borrow_amount',borrow_id='$borrow_id',user_id='$user_id' , book_id='$book_id' , library_id='$library_id'
        where borrow_id=$id");
        if($query){
            echo "updated";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Online Library | Bookstore</title>
</head>
<body>
  <nav>
    <div class="menu-icon"></div>
    <div class="logo">Digital Library</div>
  </nav>
  
  <div id="buyer-box">
    <h1 class="heading">Online Library and Bookstore</h1>
    
    <div class="input-data">
      <a href="adminManageBooks.html">
        <img class="arrow" src="../src/images/arrow.png" >
      </a>
      <h2>Update Borrow Record</h2>
      
      <link rel="stylesheet" href="addBook.css" />

      <form action="" method="post">
        <input id="book_id1" name="issue_date" type="text" placeholder="book_id" value="<?php echo $issue_date; ?>"/>
        <input id="author_name1" name="fine" type="text" placeholder="book_author" value="<?php echo $fine; ?>"/>
        <input id="book_title1" name="return_date" type="text" placeholder="book_title" value="<?php echo $return_date; ?>"/>
        <input id="s_no1" name="due_date" type="text" placeholder="s_no" value="<?php echo $due_date; ?>"/>
        
        <input id="description1" name="borrow_amount" type="text" placeholder="description" value="<?php echo $borrow_amount; ?>"/>
        <input id="book_price1" name="borrow_id" type="text" placeholder="book_price" value="<?php echo $borrow_id; ?>"/>
        <input id="admin_id1" name="user_id" type="text" placeholder="admin_id" value="<?php echo $user_id; ?>"/>
        <input id="admin_id1" name="book_id" type="text" placeholder="admin_id" value="<?php echo $book_id; ?>"/>


        <input id="library_id1" name="library_id" type="text" placeholder="library_id" value="<?php echo $library_id; ?>"/>


        

        




        <button type="submit" name="btnUpdateBorrow" >Update</button>

      </form>
    </div>

    <div class="right"></div>
  </div>
</body>
</html>