<?php
require("dbconnect.php");
$book_id = null;
$book_author = null;
$book_title = null;
$s_no = null;
$description = null;
$book_price = null;
$admin_id = null;
$library_id = null;
if($_GET["updateid"]){
    $id = $_GET["updateid"];
    $query = mysqli_query($databaseconnection, "select * from new_book where book_id=$id");
    if($query){
        while($fetchconversion = mysqli_fetch_assoc($query)){
            $book_id = $fetchconversion["book_id"];
            $book_author = $fetchconversion["book_author"];
            $book_title = $fetchconversion["book_title"];
            $s_no = $fetchconversion["s_no"];

            $description = $fetchconversion["description"];

            $book_price = $fetchconversion["book_price"];

            $admin_id = $fetchconversion["admin_id"];
            $library_id = $fetchconversion["library_id"];

        }
    }
}
if(isset($_POST["btnUpdate"])){
    $id = $_GET["updateid"];
    $book_id = htmlspecialchars(trim(stripslashes($_POST["book_id"])));
    $book_author = htmlspecialchars(trim(stripslashes($_POST["book_author"])));
    $book_title = htmlspecialchars(trim(stripslashes($_POST["book_title"])));
    $s_no = htmlspecialchars(trim(stripslashes($_POST["s_no"])));
    $description = htmlspecialchars(trim(stripslashes($_POST["description"])));
    $book_price = htmlspecialchars(trim(stripslashes($_POST["book_price"])));
    $admin_id = htmlspecialchars(trim(stripslashes($_POST["admin_id"])));
    $library_id = htmlspecialchars(trim(stripslashes($_POST["library_id"])));


    if($book_id != null && $book_author != null && $book_title != null && $s_no != null && $description != null && $book_price != null && $admin_id != null && $library_id != null){
        $query = mysqli_query($databaseconnection,"update new_book set book_id='$book_id', book_author='$book_author', book_title='$book_title',
        s_no='$s_no',description='$description',book_price='$book_price',admin_id='$admin_id' , library_id='$library_id'
        where book_id=$id");
        if($query){
            echo "updated";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Online Library | Bookstore</title>
</head>
<body>
  <nav>
    <div class="menu-icon"></div>
    <div class="logo">Digital Library</div>
  </nav>
  
  <div id="buyer-box">
    <h1 class="heading">Online Library and Bookstore</h1>
    
    <div class="input-data">
      <a href="adminManageBooks.html">
        <img class="arrow" src="../src/images/arrow.png" >
      </a>
      <h2>Edit Book Record</h2>
      
      <link rel="stylesheet" href="addBook.css" />

      <form action="" method="post">
        <input id="book_id1" name="book_id" type="text" placeholder="book_id" value="<?php echo $book_id; ?>"/>
        <input id="author_name1" name="book_author" type="text" placeholder="book_author" value="<?php echo $book_author; ?>"/>
        <input id="book_title1" name="book_title" type="text" placeholder="book_title" value="<?php echo $book_title; ?>"/>
        <input id="s_no1" name="s_no" type="text" placeholder="s_no" value="<?php echo $s_no; ?>"/>
        
        <input id="description1" name="description" type="text" placeholder="description" value="<?php echo $description; ?>"/>
        <input id="book_price1" name="book_price" type="text" placeholder="book_price" value="<?php echo $book_price; ?>"/>
        <input id="admin_id1" name="admin_id" type="text" placeholder="admin_id" value="<?php echo $admin_id; ?>"/>
        <input id="library_id1" name="library_id" type="text" placeholder="library_id" value="<?php echo $library_id; ?>"/>


        

        




        <button type="submit" name="btnUpdate" >Update</button>

      </form>
    </div>

    <div class="right"></div>
  </div>
</body>
</html>